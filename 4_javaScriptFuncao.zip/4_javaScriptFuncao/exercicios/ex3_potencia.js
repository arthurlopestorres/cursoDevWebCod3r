/*03) Crie uma função que recebe dois parâmetros, base e expoente, e retorne a base elevada ao expoente.*/
const calculaComExpoente = (base, expoente) => base ** expoente
console.log(calculaComExpoente(2, 2))