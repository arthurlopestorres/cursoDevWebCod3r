// 27) Construa uma função que receba como parâmetros as alturas e as taxas de crescimento anuais de duas
// crianças e calcule se existe uma criança menor, caso exista se a criança menor ultrapassará a maior e em
// quantos anos isso acontecerá. Utilize centímetros para as unidades de medida

function verificaCrescimento(alturaC1, alturaC2, taxaDeCrescC1, taxaDeCrescC2){
    
    let tempoParaPassarAltura = 0
    let alturaFinalC1 = alturaC1
    let alturaFinalC2 = alturaC2

    if (alturaC1 > alturaC2 && taxaDeCrescC2 > taxaDeCrescC1){
        console.log(`Uma das crianças é mais alta! A criança 1 tem ${alturaC1}cm e a criança 2 tem ${alturaC2}cm`)
        while(alturaFinalC1 > alturaFinalC2){
            alturaFinalC1 += taxaDeCrescC1
            alturaFinalC2 += taxaDeCrescC2
            tempoParaPassarAltura++
        }
        console.log(`Anos para que a menor ultrapasse a maior: ${tempoParaPassarAltura}. Altura final da criança 1: ${alturaFinalC1}cm. Altura final da criança 2: ${alturaFinalC2}cm`)
    } else if(alturaC2 > alturaC1 && taxaDeCrescC1 > taxaDeCrescC2){
        console.log(`Uma das crianças é mais alta! A criança 1 tem ${alturaC1}cm e a criança 2 tem ${alturaC2}cm`)
        while(alturaFinalC2 > alturaFinalC1){
            alturaFinalC1 += taxaDeCrescC1
            alturaFinalC2 += taxaDeCrescC2
            tempoParaPassarAltura++
        }
        console.log(`Anos para que a menor ultrapasse a maior: ${tempoParaPassarAltura}. Altura final da criança 1: ${alturaFinalC1}cm. Altura final da criança 2: ${alturaFinalC2}cm`)
    } else if (alturaC1 == alturaC2){
        console.log('as crianças possuem a mesma altura inicial')
    } else if (alturaC1 > alturaC2 && taxaDeCrescC1 == taxaDeCrescC2 || taxaDeCrescC1 > taxaDeCrescC2){
        console.log('uma será sempre menor do que a outra')
    } else if (alturaC2 > alturaC1 && taxaDeCrescC2 == taxaDeCrescC1 || taxaDeCrescC2 > taxaDeCrescC1){
        console.log('uma será sempre menor do que a outra')
    }
}
verificaCrescimento(150, 100, 2, 10)