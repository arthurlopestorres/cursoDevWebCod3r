// 19) O cardápio de uma lanchonete é o seguinte:
// Código-  Descrição do Produto - Preço
// 100 -    Cachorro Quente -      R$ 3,00
// 200 -    Hambúrguer Simples -   R$ 4,00
// 300 -    Cheeseburguer -        R$ 5,50
// 400 -    Bauru -                R$ 7,50
// 500 -    Refrigerante -         R$ 3,50
// 600 -    Suco -                 R$ 2,80
// Implemente uma função que receba como parâmetros o código do item pedido, a quantidade e calcule o valor
// a ser pago por aquele lanche. Considere que a cada execução somente será calculado um item. Use o
// comando switch. Crie um caso default para produto não existente.

function calculaValorDoPedido (codigoDoProduto, quantidade){
    let compraCod100 = 3 * quantidade
    let compraCod200 = 4 * quantidade
    let compraCod300 = 5.5 * quantidade
    let compraCod400 = 7.5 * quantidade
    let compraCod500 = 3.5 * quantidade
    let compraCod600 = 2.8 * quantidade

    switch(codigoDoProduto){
        case 100:
            return `${quantidade} Cachorro(s) Quente(s) sai(aem) por ${compraCod100}`
            break
        case 200:
            return `${quantidade} Hamburguer(s) Simples sai(aem) por ${compraCod200}`
            break
        case 300:
            return `${quantidade} Cheeseburguer(s) sai(aem) por ${compraCod300}`
            break
        case 400:
            return `${quantidade} Bauru(s) sai(aem) por ${compraCod400}`
            break
        case 500:
            return `${quantidade} Refrigerante(s) sai(aem) por ${compraCod500}`
            break
        case 600:
            return `${quantidade} Suco(s) sai(aem) por ${compraCod600}`
            break
        default:
            return 'produto não está na lista'
    }
}
console.log(calculaValorDoPedido (300, 2))