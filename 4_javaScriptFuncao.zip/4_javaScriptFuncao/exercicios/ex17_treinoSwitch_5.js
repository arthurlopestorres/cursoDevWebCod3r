// 17) Um funcionário irá receber um aumento de acordo com o seu plano de
// trabalho, de acordo com a tabela abaixo:
// Plano Aumento
// A 10%
// B 15%
// C 20%
// Faça uma função que leia o plano de trabalho e o salário atual de um funcionário e calcula e imprime o seu
// novo salário. Use a estrutura switch e faça um caso default que indique que o plano é inválido.

function calculaAumento(salario, planoDeTrabalho){
    let aumentoPlanoC = salario * 0.2
    let aumentoPlanoB = salario * 0.15
    let aumentoPlanoA = salario * 0.1

    switch(planoDeTrabalho){
        case 'a':
            return salario += aumentoPlanoA
            break
        case 'b':
            return salario += aumentoPlanoB
            break
        case 'c':
            return salario += aumentoPlanoC
            break
        default:
            'plano informado é inválido'
    }
}

console.log(calculaAumento(1000, 'c'))