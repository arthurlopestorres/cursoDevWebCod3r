// 25) Escrever um programa para exibir os números de 1 até 50 na tela
let i = 0
while(i < 50){
    console.log(i + 1)
    i++
}