// 31) Escrever um algoritmo que percorre um vetor de inteiros, conta quantos números negativos há nesse vetor
// e imprime a quantidade no console.

let vetor = [304,-108,-30,42,720,840]

function verificaQuantosNegativos(vetor){
    let quantidadeDeNegativos = 0

    for(i = 0; i < vetor.length; i++){
        if(vetor[i] < 0){
            quantidadeDeNegativos++
        }
    }
    console.log(`O total de numeros no vetor negativos é ${quantidadeDeNegativos}`)
}
verificaQuantosNegativos(vetor)