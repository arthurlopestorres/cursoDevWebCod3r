// 40) Faça uma função que receba como parâmetro um vetor de notas e mostre os conceitos de cada uma de
// modo que de 0,0 a 4,9 seja atribuído o conceito D, de 5,0 a 6,9 seja atribuído o conceito C, de 7,0 a 8,9 o
// conceito B e de 9,0 a 10,0 o conceito A.

let vetorNotas = [0.1, 5.5, 7.2, 9.3]

function verificaNotaConceito(vetorDeNotas){
    for(i in vetorDeNotas){
        if(vetorDeNotas[i] >= 0 && vetorDeNotas[i] <= 4.0){
            console.log('nota D', vetorDeNotas[i])
        } else if(vetorDeNotas[i] >= 5 && vetorDeNotas[i] <= 6.9){
            console.log('nota C', vetorDeNotas[i])
        } else if(vetorDeNotas[i] >= 7 && vetorDeNotas[i] <= 8.9){
            console.log('nota B', vetorDeNotas[i])
        } else if(vetorDeNotas[i] >= 9 && vetorDeNotas[i] <= 10){
            console.log('nota A', vetorDeNotas[i])
        }
    }
}
verificaNotaConceito(vetorNotas)