// 30) Escreva um algoritmo que percorre um vetor de inteiros e defina o maior e menor valor dentro do vetor.

let vetorDeInteiros = [6,213,418,5,7,82,30]

function encontraMaiorEMenor(vetor){
    let menorValor = vetor[0]
    let maiorValor = vetor[0]

    for(i = 0; i < vetor.length; i++){
        if(vetor[i] > maiorValor){
            maiorValor = vetor[i]
        }else if(vetor[i] < menorValor){
            menorValor = vetor[i]
        }
    }
    console.log(`O maior valor no vetor é ${maiorValor}. O menor valor no vetor é ${menorValor}`)
}
encontraMaiorEMenor(vetorDeInteiros)