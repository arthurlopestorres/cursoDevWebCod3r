// 22) Criar uma função para calcular o valor a ser pago de anuidade de uma associação. A função recebe como
// parâmetro um inteiro que representa o mês (1 - janeiro, 2 - fevereiro…) que foi paga e o valor da anuidade. A
// anuidade deve ser paga no mês de janeiro. Por mês, é cobrado 5% de juros (sob o regime de juros
// compostos). O retorno deve ser o valor a ser pago para o respectivo mês escolhido.

function valorASerPagoAnuidade(meses, valorAnuidade){
    let taxaDeJuro = 0.05
    let valorASerPago
    if (meses == 1){
        valorASerPago = valorAnuidade
        return `O valor total a ser pago é ${valorASerPago}`
    } else if(meses > 1){
        valorASerPago = `R$${(valorAnuidade * ((1 + taxaDeJuro) ** (meses - 1))).toFixed(2).replace('.', ',')}`
        return `O valor total a ser pago é ${valorASerPago}`
    } else{
        return 'quantidade de meses é inválida'
    }
}
console.log(valorASerPagoAnuidade(6, 100))