/*04) Crie uma função que irá receber dois valores, o dividendo e o divisor. A função deverá imprimir o resultado
e o resto da divisão destes dois valores.*/
const imprimeResultadoDivisaoEResto = (dividendo, divisor) => {
    console.log(`resultado da divisão: ${Math.floor(dividendo / divisor)}, resto: ${dividendo % divisor}`)
}
imprimeResultadoDivisaoEResto(2460, 3)