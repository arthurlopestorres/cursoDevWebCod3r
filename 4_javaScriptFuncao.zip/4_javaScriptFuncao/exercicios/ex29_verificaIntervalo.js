// 29) Utilizando a estrutura de repetição for, faça uma função que percorra um vetor e conte quantos números
// deste vetor estão no intervalo [10,20] (repare que o intervalo é fechado, ou seja, inclui o 10 e o 20) e quantos
// deles estão fora do intervalo, escrevendo estas informações.

let vetorDeNumeros = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]

function verificaIntervalo(vetor){
    let inicialIntervalo = 2
    let finalIntervalo = 10

    let qtdItensNoIntervalo = 0
    let noIntervalo = []
    
    let qtdItensForaIntervalo = 0
    let foraDoIntervalo = []

    for(i = 0; i < vetor.length; i++){
        if (vetor[i] >= inicialIntervalo && vetor[i] <= finalIntervalo){
            qtdItensNoIntervalo++
            noIntervalo.push(vetor[i])
        }else if (vetor[i] < inicialIntervalo || vetor[i] > finalIntervalo){
            qtdItensForaIntervalo++
            foraDoIntervalo.push(vetor[i])
        }
    }
    console.log('No intervalo:', noIntervalo)
    console.log('Fora do intervalo:', foraDoIntervalo)
    console.log(`${qtdItensNoIntervalo} números estão no intervalor de ${inicialIntervalo} a ${finalIntervalo}. ${qtdItensForaIntervalo} números estão fora do intervalo de ${inicialIntervalo} a ${finalIntervalo}`)
}

verificaIntervalo(vetorDeNumeros)