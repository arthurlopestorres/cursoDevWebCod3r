// 12) Faça um algoritmo que calcule o fatorial de um número.
function calculaFatorial(valor) {
    let numeroInicial = valor
    let resultadoFinal = valor

    if (numeroInicial == 0){
        resultadoFinal = 1
    }
    while(numeroInicial > 1){
        --numeroInicial 
        resultadoFinal *= numeroInicial
    }
    
    console.log(resultadoFinal)
}
calculaFatorial(4)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Outra forma de resolver, utilizando callback:
function fatorial (numero) {
    if(numero == 0){
        return 1
    } else {
        return numero * fatorial(numero - 1)
    }
}

console.log(fatorial(4))