//01) Crie uma função que dado dois valores (passados como parâmetros) mostre no console a soma, subtração, multiplicação e divisão desses valores.
function fazOperacoesMatematicas(x, y){
    let soma = x + y
    let subtracao = x - y
    let multiplicacao = x * y
    let divisao = x / y
    console.log(`soma:${soma}, subtracao:${subtracao}, multiplicacao:${multiplicacao}, divisao: ${divisao}`)  
}
fazOperacoesMatematicas(5, 10)