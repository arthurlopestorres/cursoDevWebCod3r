// 28) Ler um vetor de números inteiros e imprimir quantos são pares e quantos são ímpares.
let vetorDeNumerosInteiros = [0, 1, 'Arthur', 3, 4, 5, 6, 7, 8, 9, 10]

function verificaParesEImpares(vetor){
    let quantidadePares = 0
    let quantidadeImpares = 0
    let quantidadeDeInvalidos = 0

    for(i = 0; i < vetor.length; i++){
        if(isNaN(vetor[i]) || !Number.isInteger(vetor[i])){
            quantidadeDeInvalidos++
        } else if (vetor[i] % 2 == 0){
            quantidadePares++
        } else if (vetor[i] % 2 != 0){
            quantidadeImpares++
        }
    }

    return `Quantidade de invalidos: ${quantidadeDeInvalidos}, quantidade de pares = ${quantidadePares} e quantidade de ímpares = ${quantidadeImpares}`
}
console.log(verificaParesEImpares(vetorDeNumerosInteiros))