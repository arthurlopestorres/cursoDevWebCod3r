// 36) Crie duas funções que recebem dois parâmetros, um vetor com apenas valores numéricos e um número
// inteiro. Faça com que a primeira função retorne outro vetor que será resultado da multiplicação de cada
// elemento pelo número passado como parâmetro. A segunda função fará o mesmo da primeira se e somente se
// o valor do elemento for maior que 5.

let vetor = [23,2,802,587,351]

function geraArrayMultiplicado(vetor, numero){ //essa deve retornar outro vetor(array), em que cada valor sera o mesmo que (vetor[i]*numero)
    let resultadoDaMultiplicacao = 0
    let vetorResultado = []

    for(i in vetor){
        resultadoDaMultiplicacao = vetor[i] * numero
        vetorResultado.push(resultadoDaMultiplicacao)
    }
    console.log(vetorResultado)
}

function geraArrayMultiplicadoSeMaiorQue5(vetor, numero){
    let resultadoDaMultiplicacao = 0
    let vetorResultado = []

    for(i in vetor){
        if (vetor[i] > 5){
            resultadoDaMultiplicacao = vetor[i] * numero
            vetorResultado.push(resultadoDaMultiplicacao)
        }else {
            vetorResultado.push(vetor[i])
        }
    }
    console.log(vetorResultado)
}

geraArrayMultiplicado(vetor, 2)
geraArrayMultiplicadoSeMaiorQue5(vetor, 2)