// 10) Crie uma função que verifica se um número inteiro passado como parêmetro é divisível por 3 e retorne true
// ou false
function verificaSeDivisivelPor(valorDividivo, valorDividendo) {
    let restoDaDivisao = valorDividivo % valorDividendo
    if (!Number.isInteger(valorDividivo) || isNaN(valorDividivo)){
        return 'valor não é inteiro ou numérico -- valor invalido'
    } else if (restoDaDivisao == 0){
        return true
    } else {
        return false
    }
}
console.log(verificaSeDivisivelPor(6, 3))