// 14) Crie uma estrutura condicional switch que receba uma string com o nome de uma fruta e que possua três
// casos: Caso maçã, retorne no console: “Não vendemos esta fruta aqui”. Caso kiwi, retorne: “Estamos com
// escassez de kiwis”. Caso melancia, retorne: “Aqui está, são 3 reais o quilo”. Teste com estas três opções .Crie
// também um default, que retornará uma mensagem de erro no console.
function verificaSeFrutaDisponivel(fruta){
    if(!isNaN(fruta)){
        return 'precisa ser o nome de uma fruta'
    }else{
        switch(fruta){
            case 'Maça':
                return 'não vendemos esta fruta aqui'
                break
            case 'Kiwis':
                return 'Estamos com escassez de kiwis'
                break
            case 'Melancia':
                return 'Aqui está, são 3 reais o quilo'
                break
            default:
                return 'Esta fruta não existe no planeta terra (ou não aqui, pelo menos)'
                break
        }
    }
}

console.log(verificaSeFrutaDisponivel('banana'))