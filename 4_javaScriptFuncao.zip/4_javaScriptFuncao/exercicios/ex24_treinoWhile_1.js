// 24) Crie um programa que imprima 11 vezes a frase " Hello World!" utilizando uma estrutura de repetição while.

let index = 0

while (index < 11) {
    console.log((index + 1), 'Hello World!')
    index++
}