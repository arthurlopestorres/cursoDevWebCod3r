// 18) Faça um programa que leia um número entre 0 e 10, e escreva este número por extenso. Use o comando
// switch. Crie um case default que escreva ‘Número fora do intervalo.’

function escreveNumeroPorExtenso(numero){
    if(isNaN(numero)){
        return 'o valor precisa ser numérico'
    }else {
        switch(numero){
            case 1: 
                return 'um'
                break
            case 2:
                return 'dois'
                break
            case 3:
                return 'três'
                break
            case 4:
                return 'quatro'
                break
            case 5:
                return 'cinco'
                break
            case 6:
                return 'seis'
                break
            case 7:
                return 'sete'
                break
            case 8:
                return 'oito'
                break
            case 9:
                return 'nove'
                break
            default:
                return 'Número fora do intervalo'
        }
    }
    
}
console.log(escreveNumeroPorExtenso(10))