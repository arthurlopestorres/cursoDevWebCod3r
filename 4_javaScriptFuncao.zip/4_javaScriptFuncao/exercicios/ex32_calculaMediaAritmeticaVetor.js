// 32) Construir um algoritmo que calcule a média aritmética dos valores de um vetor de inteiros.

let vetor = [630,920,450,7,300,15]

function calculaMediaAritmetica(vetor){
    let somaTotal = 0
    let divisor = vetor.length

    for(i in vetor){
        somaTotal += vetor[i]
    }

    console.log(`A média aritmética do vetor é ${somaTotal / divisor}`)
}
calculaMediaAritmetica(vetor)