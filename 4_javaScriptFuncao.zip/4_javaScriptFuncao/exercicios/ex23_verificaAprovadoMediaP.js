// 23) Escreva um algoritmo que leia o código de um aluno e suas três notas. Calcule a média ponderada do
// aluno, considerando que o peso para a maior nota seja 4 e para as duas restantes, 3. Mostre o código do
// aluno, suas três notas, a média calculada e uma mensagem "APROVADO" se a média for maior ou igual a 5 e
// "REPROVADO" se a média for menor que 5. Repita a operação até que o código lido seja negativo.

//algoritmo le codigo do aluno e 3 notas
//calcular media ponderada -> maior nota tem peso 4 e outras duas tem peso 3.
//se media >= 5 -> "aprovado"
//se media < 5 -> "reprovado"

//calcular media ponderada: nota * peso + nota * peso / soma dos pesos, que é 10

const alunosESuasNotas = [
    {nome: 'Arthur', nota1: 9, nota2: 8, nota3: 7},
    {nome: 'Izabelle', nota1: 10, nota2: 7, nota3: 8},
    {nome: 'Joao', nota1: 5, nota2: 4, nota3: 3},
    {nome: 'Rogerio', nota1: 7, nota2: 4.5, nota3: 6.8}
]

function calculaMediaPonderada(listaDeAlunos){
    let mediaPonderada
    let peso1 = 4
    let peso2 = 3
    
    for(i = (listaDeAlunos.length - 1); i >= 0; i--){
        let nota1 = listaDeAlunos[i].nota1
        let nota2 = listaDeAlunos[i].nota2
        let nota3 = listaDeAlunos[i].nota3

        if(nota1 > nota2 && nota1 > nota3){
            mediaPonderada = (((nota1 * peso1) + (nota2 * peso2) + (nota3 * peso2)) / (peso1 + (peso2 * 2))).toFixed(1)
        } else if(nota2 > nota1 && nota2 > nota3){
            mediaPonderada = (((nota2 * peso1) + (nota1 * peso2) + (nota3 * peso2)) / (peso1 + (peso2 * 2))).toFixed(1)
        } else if(nota3 > nota1 && nota3 > nota2){ 
            mediaPonderada = (((nota3 * peso1) + (nota2 * peso2) + (nota1 * peso2)) / (peso1 + (peso2 * 2))).toFixed(1)
        } else if(nota1 == nota2 && nota2 == nota3){
            mediaPonderada = ((nota1 + nota2 + nota3) / 3).toFixed(1)
        }
        
        if(mediaPonderada >= 5){
            console.log(`${i}, que tirous as notas ${listaDeAlunos[i].nota1}, ${listaDeAlunos[i].nota2} e ${listaDeAlunos[i].nota3}, com média de ${mediaPonderada} está aprovado(a)`) 
        }else {
            console.log(`${i}, que tirous as notas ${listaDeAlunos[i].nota1}, ${listaDeAlunos[i].nota2} e ${listaDeAlunos[i].nota3}, com média de ${mediaPonderada} está reprovado(a)`) 
        }
    }

}
calculaMediaPonderada(alunosESuasNotas)