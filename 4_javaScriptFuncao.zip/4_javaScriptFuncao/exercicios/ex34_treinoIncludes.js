// 34) Construa uma função que receberá duas Strings de tamanhos variados e que retornará True ou False caso
// todos os caracteres (independentemente de ser maiúsculo ou minúsculo) estejam contidos em ambas palavras

function verificaSeTodasAsLetrasPresentes (string1, string2){
    let validador = false
    let string1Oficial = string1.toLowerCase()
    let string2Oficial = string2.toLowerCase()

    if (string1Oficial.length > string2Oficial.length || string1Oficial.length == string2Oficial.length){
        for(i in string2Oficial){
            if(string1Oficial.includes(string2Oficial.charAt(i))){
                validador = true
            }else {
                validador = false
                break
            }
        }
    } else {
        for(i in string1Oficial){
            if(string2Oficial.includes(string1Oficial.charAt(i))){
                validador = true
            }else {
                validador = false
                break
            }
        }
    }
    
    console.log(validador)
}
verificaSeTodasAsLetrasPresentes ('Arthur', 'A')