// 37) Escreva duas funções, uma para progressão aritmética e uma para progressão geométrica que recebam
// como parâmetros um número n (número de termos), a1 (o primeiro termo) e r (a razão) e escreva os n termos ,
// bem como a soma dos elementos.

//PA é uma sequencia numerica em que a razao define quem sera o proximo numero. Na PA, a razão é sempre o numero seguinte - anterior. 
//Formula da PA: An = Ap + (n - p)*r

function prograssaoAritmetica(numeroDeTermos, primeiroTermo, razao){
    let termosDaPa = []
    let valorAtual = primeiroTermo
    let somaDosTermos = 0

    for(i = 1; i <= numeroDeTermos; i++) {
        termosDaPa.push(valorAtual)
        valorAtual += razao
    }
    console.log('os termos da Pa são:', termosDaPa)

    for(i = 0; i < termosDaPa.length; i++){
        somaDosTermos += termosDaPa[i]
    }
    console.log('a soma dos termos é:', somaDosTermos)
}
prograssaoAritmetica(10, 2, 2)

//PG -> a razão é multiplicada pelo temos, mas tem a mesma ideia da PA

function prograssaoGeometrica(numeroDeTermos, primeiroTermo, razao){
    let termosDaPa = []
    let valorAtual = primeiroTermo
    let somaDosTermos = 0

    for(i = 1; i <= numeroDeTermos; i++) {
        termosDaPa.push(valorAtual)
        valorAtual *= razao
    }
    console.log('os termos da Pa são:', termosDaPa)

    for(i = 0; i < termosDaPa.length; i++){
        somaDosTermos += termosDaPa[i]
    }
    console.log('a soma dos termos é:', somaDosTermos)
}
prograssaoGeometrica(10, 2, 2)